import { useRouter } from "expo-router";
import { useState } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import { useOnboardingStore } from "@/stores/onboarding-store";
import { ContinueButton } from "../common/continue-button";
import { StepHeader } from "../common/step-header";

export function ZoneImpactScreen() {
	const router = useRouter();
	const { zoneImpact, bodyZoneSelected, setAnswer, nextStep } =
		useOnboardingStore();
	const [selected, setSelected] = useState<number | null>(zoneImpact ?? null);

	const zoneName = bodyZoneSelected?.length
		? bodyZoneSelected.join(" & ")
		: "this area";

	const handleContinue = () => {
		if (selected !== null) {
			setAnswer("zoneImpact", selected);
			nextStep();
			router.push("/(onboarding)/19");
		}
	};

	const options = [
		{
			value: 1,
			label: "Limits my activities",
			icon: "⛔",
			desc: "Can't do things I enjoy",
		},
		{
			value: 2,
			label: "Affects my sleep",
			icon: "😴",
			desc: "Wakes me up or prevents rest",
		},
		{
			value: 3,
			label: "Mental/emotional stress",
			icon: "😟",
			desc: "Worries or depresses me",
		},
		{
			value: 4,
			label: "Affects my work/productivity",
			icon: "💼",
			desc: "Interferes with daily tasks",
		},
		{ value: 5, label: "Minimal impact", icon: "✓", desc: "I manage it fine" },
	];

	return (
		<View className="flex-1 bg-[#EBF5F4]">
			<View className="flex-1 justify-between px-6 pb-10">
				<ScrollView
					className="flex-1"
					contentContainerStyle={{ flexGrow: 1, paddingBottom: 40 }}
					showsVerticalScrollIndicator={false}
				>
					<View className="flex-1">
						<StepHeader
							className="mt-8"
							description={`What's the biggest impact of your ${zoneName} concerns?`}
							title="How does it affect you?"
						/>

						<View className="mt-8 gap-3">
							{options.map(({ value, label, icon, desc }) => {
								const isSelected = selected === value;
								return (
									<TouchableOpacity
										activeOpacity={0.7}
										className={`flex-row items-center justify-between overflow-hidden rounded-2xl border-2 p-4 ${
											isSelected
												? "border-[#28B898] bg-[#28B898]/10"
												: "border-transparent bg-white shadow-[#28B898]/5 shadow-sm"
										}`}
										key={value}
										onPress={() => setSelected(value)}
									>
										<View className="flex-1">
											<Text
												className={`font-bold text-base ${
													isSelected ? "text-[#28B898]" : "text-[#0d2137]"
												}`}
											>
												{label}
											</Text>
											<Text
												className={`mt-1 text-xs ${
													isSelected ? "text-[#28B898]/80" : "text-[#73808C]"
												}`}
											>
												{desc}
											</Text>
										</View>
										<Text className="text-2xl">{icon}</Text>
									</TouchableOpacity>
								);
							})}
						</View>

						<View className="mt-8 rounded-2xl border border-blue-100 bg-blue-50/50 p-4">
							<Text className="text-[#64748B] text-xs leading-5">
								✨ Understanding the impact helps us prioritize what matters
								most to you in your personalized plan.
							</Text>
						</View>
					</View>
				</ScrollView>

				<View className="pt-6">
					<ContinueButton
						isDisabled={selected === null}
						onPress={handleContinue}
					/>
				</View>
			</View>
		</View>
	);
}
